# King EX75 (The Disk King)

**King EX75 by The Disk King: Inspired by the Akai EX75N noise reduction (1987).** A half-rack 80s noise gate /
expander for Akai MPC standalone hardware, in the King rack with King EX85 above it and King EX90 below (darkened;
each works with its own plugin). It has:
- **THRESHOLD** -50 to -10 dB: below it the sound is turned down;
- **RATIO** 1:1 to 1:8: from a gentle expander to nearly a gate;
- a fast 0.3 ms attack and a **DECAY** of 0.2 to 2 seconds, Akai's own figures;
- **FILTER** OFF or 200 Hz to 5 kHz (6 dB/oct): rolls the hiss off when the sound gets quiet;
- a **REDUCTION** light, an **EFFECT** rocker, **POWER** and a **HELP** card.

**Version 1.0.0. Use at your own risk.**

## This is an EFFECT: find it in Insert Effects

1. Open the **Mixer** (or a track's / pad's **Insert Effects**) and tap an empty **Insert** slot.
2. Choose **External Plugins → The Disk King → King EX75**. Tap the edit (pencil) icon to see the panel.
3. Pick a preset from the **preset name at the top of the plugin window**, then play.
4. Press **HELP** (bottom left of the panel) any time.

Needs MPC OS 3.10.1 or later, with **Preferences → Enhancements (Beta) → Enable Enhancements** and
**External Plugin Support** turned on.

## Setting it up

Play the sound. Turn **THRESHOLD** up until the hiss (or the spill between hits) goes away but the part you want to keep
still comes through whole. The red **REDUCTION** light shows when it is working. Higher **RATIO** = harder cut; longer
**DECAY** = smoother tails. Turn **FILTER** up from OFF to also take the hiss off quiet bits (lower = darker).
Q-Links: top row THRESHOLD, RATIO, DECAY, FILTER; second row EFFECT.

## Presets

The EX75N had no memory (all knobs), so these are standard noise gate / expander settings, every one made only from the
knobs on the panel.

| Preset | THRESHOLD | RATIO | DECAY | FILTER | Use it on |
|---|---|---|---|---|---|
| Default | -40 dB | 1:2 | 0.5 s | OFF | A gentle start (loads first) |
| Tape Hiss | -45 dB | 1:2 | 0.8 s | 3 kHz | Cassette and reel-to-reel hiss |
| Vinyl Sample Hiss | -42 dB | 1:1.5 | 1.0 s | 4 kHz | Samples from records: hiss in the gaps |
| Old Sampler Noise | -46 dB | 1:2 | 0.6 s | 5 kHz | The noise floor of old 12-bit samplers |
| Synth Pad Hiss | -48 dB | 1:1.5 | 2.0 s | 3 kHz | Old synths: long tails stay smooth |
| Guitar Amp Buzz | -40 dB | 1:4 | 0.3 s | 2 kHz | Amp hiss and buzz between notes |
| Vocal Cleanup | -38 dB | 1:3 | 0.4 s | OFF | Room noise and breaths between lines |
| Drum Gate Tight | -25 dB | 1:8 | 0.2 s | OFF | Tight, punchy drum hits |
| Snare Spill Gate | -22 dB | 1:6 | 0.25 s | OFF | A snare track: the kick and hats bleeding in |
| Tom Gate | -28 dB | 1:6 | 0.6 s | OFF | Toms: keep the ring, cut the spill |
| Gentle Expander | -35 dB | 1:1.5 | 0.8 s | OFF | A whole mix: a little more space |
| Hard Gate | -20 dB | 1:8 | 0.2 s | OFF | Choppy, gated effects |

All presets start with EFFECT in and POWER on.

## About the EX75N

Akai brought out the EX75N in 1987 in its EX series of half-rack effects. Akai's 1988-89 catalogue gives: ratio 1:1 to
1:8, attack under 0.3 ms, decay 0.2 to 2 s, low-pass filter 200 Hz to 5 kHz at 6 dB/oct, response 10 Hz to 30 kHz.
King EX75 follows those figures and the panel's THRESHOLD (-50 to -10 dB). The original is mono; King EX75 is stereo
(one detector, both sides together).

*Akai and EX75N are trademarks of their owner. The Disk King is not affiliated with or endorsed by them; the name is
used only to say which classic unit King EX75 is inspired by. The KING logo is The Disk King's own.*

## Known limits

- Like every MPC insert effect, it only works while sound plays through it.

## Disclaimer

Provided as is, with no warranty of any kind. Use entirely at your own risk; The Disk King is not responsible in any way
for any loss, damage or problem from using it.

More MPC sounds: https://thediskking.com
