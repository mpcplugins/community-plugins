# King EX65 (The Disk King)

King EX65 by The Disk King: Inspired by the Akai EX65D digital delay (1987). Delay time RANGE (2, 8, 32, 128, 512 ms) x MULTI (x0.5 to x2) = 1 to 1024 ms, FEED BACK, RATE and WIDTH modulation (chorus, flanger, doubling, tape wobble), DELAY LEVEL, HOLD (loops the echoes forever), INPUT light, EFFECT in/out with the echoes ringing out.

See Ideas/ in the MPC Plugins folder for the research and plan. Version 1.0.0. Use at your own risk.

*Akai is a trademark of its owner. The Disk King is not affiliated with or endorsed by Akai; the model name is used only to say which classic unit this plugin is inspired by.*
