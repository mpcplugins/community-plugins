# King EX85 (The Disk King)

**King EX85 by The Disk King: Inspired by the Akai EX85P parametric equalizer (1987).** A half-rack 80s four-band
EQ for Akai MPC standalone hardware. It sits in the King rack under King EX90 (the EX90 shows darkened above it; it
works with its own plugin). It has:
- a **LOW** shelf at 40 Hz and a **HI** shelf at 12 kHz, each -14 to +14 dB;
- two sweepable mid bands: **MID LOW** 60 Hz to 5 kHz and **MID HI** 100 Hz to 10 kHz, each -18 to +18 dB;
- the original's **dual BAND WIDTH** knob: its own width (Q 6 narrow to 1 wide, Akai's figures) for each mid band;
- an **EFFECT** rocker to switch the EQ in and out, **POWER** and a **HELP** card.

**Version 1.0.0. Use at your own risk.**

## This is an EFFECT: find it in Insert Effects

1. Open the **Mixer** (or a track's / pad's **Insert Effects**) and tap an empty **Insert** slot.
2. Choose **External Plugins → The Disk King → King EX85**. Tap the slot's edit (pencil) icon to see the panel.
3. Pick a preset from the **preset name at the top of the plugin window**, then play.
4. Press **HELP** (bottom left of the panel) any time.

Needs MPC OS 3.10.1 or later, with **Preferences → Enhancements (Beta) → Enable Enhancements** and
**External Plugin Support** turned on.

## Turning the knobs

**Slide your finger up to turn a knob right, slide down to turn it left.** 12 o'clock on every LEVEL knob is flat.
The Q-Link knobs work too: top row LOW, MID LOW FRQ, MID LOW LEVEL, MID HI FRQ; second row MID HI LEVEL, HI,
BAND WIDTH (MID HI), BAND WIDTH (MID LOW); third row EFFECT.

## The controls

| Control | What it does |
|---|---|
| LOW (40Hz) LEVEL | Bass shelf: -14 .. +14 dB. Adds or takes away the deep low end. |
| MID LOW FRQ | Picks the low-mid frequency, 60 Hz .. 5 kHz. |
| MID LOW LEVEL | Cuts or boosts that frequency, -18 .. +18 dB. |
| MID HI FRQ | Picks the high-mid frequency, 100 Hz .. 10 kHz. |
| MID HI LEVEL | Cuts or boosts that frequency, -18 .. +18 dB. |
| HI (12kHz) LEVEL | Treble shelf: -14 .. +14 dB. Air and sparkle, or darker. |
| BAND WIDTH | Two knobs in one, like the original's stacked pot. **Touch the left half for MID HI, the right half for MID LOW.** The pointer on the cap shows MID HI, the glow dot on the ring shows MID LOW. Left = narrow (Q 6, a sharp peak or notch), right = wide (Q 1, a broad curve). |
| EFFECT rocker + light | Puts the EQ in or out, so you can compare. Rocker up and light on = in. |
| POWER | Tap the red light. Off = the sound passes untouched. |
| HELP | Opens the help card; CLOSE (or HELP again) puts it away. |

## Presets

The EX85P had no memory (all knobs), so these are standard EQ moves. Every preset is made only from the knobs on the
panel. Q = BAND WIDTH (higher = narrower).

| Preset | LOW | MID LOW | MID HI | HI | Use it on |
|---|---|---|---|---|---|
| Default | 0 | 300 Hz, 0 dB | 2 kHz, 0 dB | 0 | Flat (loads first) |
| Kick Punch | +5 | 380 Hz -6 dB, Q 2 | 3.5 kHz +4 dB, Q 1.4 | 0 | Kick: more weight, less box, more beater click |
| Snare Crack | -3 | 200 Hz +3 dB, Q 1.4 | 5 kHz +4 dB, Q 1 | +2 | Snare: body and crack |
| Hi-Hat Air | -14 | 400 Hz -4 dB, Q 1 | 8 kHz +3 dB, Q 1 | +5 | Hats and cymbals: no low junk, more shine |
| Vocal Presence | -6 | 250 Hz -3 dB, Q 1.4 | 3 kHz +4 dB, Q 1.2 | +3 | Vocals: less mud, more forward |
| De-Mud | 0 | 300 Hz -4 dB, Q 1 | flat | 0 | A busy mix or sample: clears the boxy low mids |
| Bass Weight | +4 | 100 Hz +3 dB, Q 1 | 800 Hz +3 dB, Q 1.4 | -4 | Bass: heavier, and heard on small speakers |
| Boom Bap Drums | +3 | 100 Hz +2 dB, Q 1 | 2.5 kHz +3 dB, Q 1 | -3 | A drum loop: fat bottom, punchy, dusty top |
| Telephone | -14 | 100 Hz -18 dB, Q 1 | 1.5 kHz +8 dB, Q 1 | -14 | The old phone / radio voice |
| Sample Warmth | +2 | 200 Hz +2 dB, Q 1 | 4 kHz -3 dB, Q 1 | -6 | Records and samples: warm and soft |
| Notch Hunter | 0 | flat | 1 kHz +15 dB, Q 6 | 0 | Sweep MID HI FRQ to find a ring, then turn MID HI LEVEL down past 12 o'clock to cut it |
| Bright Mix | +1 | flat | 3 kHz +1.5 dB, Q 1 | +4 | A whole beat: a little open and bright |

All presets start with EFFECT in and POWER on.

## About the EX85P

Akai brought out the EX85P in 1987 as part of its EX series of half-rack effects (GBP 139). It is an analog,
all-knob four-band EQ: fixed shelves at 40 Hz and 12 kHz (+-14 dB, Q 0.5), two sweepable mids (60 Hz to 5 kHz and 100 Hz
to 10 kHz, +-18 dB), and a dual stacked BAND WIDTH pot that sets the width of each mid (Q 1 to 6), all as in
Akai's 1988-89 catalogue. An EFFECT button with a light
switches it in and out. King EX85 follows that panel; the panel itself is King EX90's, as the two were sister units.
The original is mono; King EX85 is stereo (both sides get the same EQ).

*Akai and EX85P are trademarks of their owner. The Disk King is not affiliated with or endorsed by them; the name is
used only to say which classic unit King EX85 is inspired by. The KING logo is The Disk King's own.*

## Known limits

- Like every MPC insert effect, it only works while sound plays through it.
- Big boosts can clip, like on the original: turn a LEVEL down if it distorts.

## Disclaimer

Provided as is, with no warranty of any kind. Use entirely at your own risk; The Disk King is not responsible in any way
for any loss, damage or problem from using it.

More MPC sounds: https://thediskking.com
