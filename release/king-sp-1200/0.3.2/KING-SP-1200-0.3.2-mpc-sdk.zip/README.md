# KING SP-1200

KING SP-1200 by The Disk King: Inspired by the E-mu SP-1200 (the original 1987 machine). Not affiliated with E-mu.

An instrument plugin for Akai MPC standalone (MPC OS 3.10.1 or later; turn on Preferences > Enhancements (Beta) >
Enable Enhancements and External Plugin Support).

## What it is

- 12-bit sound at 26,040 samples a second, 10.0 seconds of memory, no sound longer than 2.5 seconds.
- 32 sounds: banks A-D, 8 pads each. MPC pads play them: notes 37-68 (pad bank A = A1-B8, pad bank B = C1-D8).
- 8 channels with one voice each, like the original: a new hit on a channel cuts the last one.
- Channel filters: 1-2 dynamic 4-pole low-pass that closes after each hit, 3-6 fixed low-pass, 7-8 none.
- Outputs 1-2 = the mix. Outputs 3-18 = channels 1-8 on their own pairs, for the MPC mixer.
- Pitch is done by playback rate with no smoothing, so you get the gritty steps when you tune down.

## The panel (two pages)

PERFORM: Programming keys, the 8 sliders (Q-Links 1-8), Tune/Decay-Mix switch, Bank A-D, 8 pads, LCD, Tempo,
arrows, Enter, keypad (7 = No, 9 = Yes), Tap, Run/Stop, Record.
MODULES: Set-up, Disk, Sync, Sample, the Sample level knob, Mix Volume and Metronome Volume, Programming, pads.

Works now:
- Set-up 11 Multi Pitch, 12 Multi Level, 13 Exit Multi, 14 Dynamic Buttons, 15 Define Mix, 16 Select Mix,
  17 Channel Assign, 18 Decay/Tune Select, 19 Loop/Truncate (sliders 1-2 start, 3-4 end, 5-6 loop), 20 Delete Sound,
  22 MIDI channel + Omni/Poly, 23 Special.
- Special 12 Clear All, 13 Memory Remaining, 15 Clear Sounds, 17 Copy Sound, 18 Swap Sounds, 19 Default Decay,
  20 Init DK/Tune, 21 Name Sound, 22 Dynamic Allocation, 25 Reverse Sound. Slider 1 scrolls the list, Enter picks.
- Disk: 2 Save Sounds, 5 / 0 Load Sounds, 6 Load Sound #, 8 Catalog Sounds. A disk is the folder
  "KING SP-1200 Disks/Disk NN" at the top of the MPC drive (arrows pick the disk). Drop any WAVs there: files named
  "A1 ...", "B3 ..." go to that pad, others fill the empty pads. They are turned into 12-bit 26 kHz sound.
- Sync 1-4 (the MPC's clock is used).
- Tempo: arrows or four digits (0935 = 93.5).
- Sounds, mixes and settings are saved in the MPC project.

Not in this version (the LCD says so when pressed):
- The sequencer: segments, songs, the Programming keys, Run/Stop, Tap/Repeat, Record, Set-up 21, Special 16,
  Disk 1/3/4/7. Use the MPC's own sequencer meanwhile.
- Sampling: an MPC instrument plugin gets no audio input, so sampling comes as a companion effect
  (KING SP-1200 Sampler). Meanwhile, sample with the MPC and drop the WAV on a disk folder.
- Not possible on the MPC: SMPTE writing, MIDI sample dumps, formatting floppies.

The starting kit in bank A is made by the plugin itself (no factory sounds).

## Build

```
python tools/build.py "plugins/KING SP-1200"
python "plugins/KING SP-1200/make_skin.py"
python tools/build.py "plugins/KING SP-1200"
```
Art: design/ (Jason's panel.png, fader_caps.png, sp1200.psd). Panel test: test/sp_test.cpp. Plan:
Desktop\MPC Plugins\Ideas\KING SP-1200\PLAN.md.

CPU: about 0.06% of a desktop core in the simulator (8 voices, very light).
