# King EX80 (The Disk King)

King EX80 by The Disk King: Inspired by the Akai EX80E enhancer (1987). Generates new upper harmonics to brighten dull sounds: INPUT with an input light, INTENSITY (how much the harmonic generator is driven), FILTER 1 to 5 kHz (12 dB/oct, the band that feeds it), MIX (how much is added), EFFECT in/out.

See Ideas/ in the MPC Plugins folder for the research and plan. Version 1.0.0. Use at your own risk.

*Akai is a trademark of its owner. The Disk King is not affiliated with or endorsed by Akai; the model name is used only to say which classic unit this plugin is inspired by.*
