# King EX70 (The Disk King)

**King EX70 by The Disk King: Inspired by the Akai EX70C comp / gate (1987).** A half-rack 80s compressor and noise
gate for Akai MPC standalone hardware, in the King rack with the other King units (darkened above and below it; each
works with its own plugin).

**Version 1.0.0. Use at your own risk.**

## Find it in Insert Effects
Mixer (or a track's / pad's Insert Effects) → empty Insert slot → **External Plugins → The Disk King → King EX70**.
Needs MPC OS 3.10.1+, with Preferences → Enhancements (Beta) → Enable Enhancements and External Plugin Support on.

## The controls (as on the EX70C)

| Control | What it does |
|---|---|
| INPUT (-6 .. -42 dB, red knob) | Where the compression starts. Turn right for more squeeze. |
| RATIO (2:1 .. 20:1) | How hard: 2:1 gentle, 4:1 firm, 20:1 a limiter. |
| ATTACK (0.2 .. 40 ms) | Fast grabs every hit; slow lets the punch of each hit through first. |
| RELEASE (0.04 .. 1.5 s) | Fast and pumping, or slow and smooth. |
| OUTPUT | Makes up the level the compression took away (-20 .. +20 dB, 12 o'clock = 0). |
| THRESHOLD (OFF .. MAX) | The gate: shuts out anything quieter than this (-70 .. -10 dB). |
| DECAY (MIN .. MAX) | How fast the gate shuts: 5 ms (tight) to 1.5 s (smooth). |
| COMP REDUCTION light | Lit while it compresses 2 dB or more. |
| GATE REDUCTION light | Lit while the gate is shutting the sound out. |
| EFFECT rocker + light, POWER, HELP | In / out, bypass, and the help card. |

At most 32 dB of compression, as Akai's catalogue says. Q-Links: top row INPUT, RATIO, ATTACK, RELEASE; second row
OUTPUT, THRESHOLD, DECAY, EFFECT.

## Presets (the EX70C had none; standard compressor / gate settings)
Default, Vocal Smooth, Vocal Comp + Gate, Kick Punch, Snare Snap, Snare Gate Tight, Drum Bus Glue, Bass Even,
808 Control, Boom Bap Squash, Limiter, Guitar Sustain, Noisy Sample Gate.

## About the EX70C
Akai's EX series compressor/gate (1987). Akai's 1988-89 catalogue: compressor attack 0.2 to 40 ms, release 40 ms to
1.5 s, maximum compression 32 dB, gate decay 5 ms to 1.5 s. Two units linked with SYNC for stereo; King EX70 is always
stereo-linked. Not published anywhere free, so chosen by The Disk King: the gate's dB range, the OUTPUT range.

*Akai and EX70C are trademarks of their owner. The Disk King is not affiliated with or endorsed by them; the name is
used only to say which classic unit King EX70 is inspired by. The KING logo is The Disk King's own.*

## Disclaimer
Provided as is, with no warranty of any kind. Use entirely at your own risk.

More MPC sounds: https://thediskking.com
