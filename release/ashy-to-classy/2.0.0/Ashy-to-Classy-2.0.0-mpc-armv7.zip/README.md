# Ashy to Classy

MPC insert effect by The Disk King (uid TDAC). Left side cleans records, right side ages them.
Skin = Jason's own console design (design/), made live by make_skin.py.

Rebuild: python tools/build.py "plugins/Ashy to Classy"; python "plugins/Ashy to Classy/make_skin.py"; python tools/build.py "plugins/Ashy to Classy"

Offline sound tests: test/ (make_dirty_sample.py, render.cpp, sweep.py).
